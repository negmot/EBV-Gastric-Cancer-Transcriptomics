#!/usr/bin/env python3
import json, math, shutil, zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import minimize
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "input"
OUT = ROOT / "results"
FIG = ROOT / "figures"
PKG = ROOT / "package"
for p in (OUT, FIG, PKG): p.mkdir(parents=True, exist_ok=True)

GENES = ["CD8A","IFNG","CCR7","PTPRC","GZMB","TNFRSF4","NCR1","IL21R","CXCR6","ENTPD1","CD2","LCK"]

def wide(filename, key):
    d = pd.DataFrame(json.loads((RAW / filename).read_text()))
    return d.pivot_table(index=key, columns="clinicalAttributeId", values="value", aggfunc="first").reset_index()

def bh(values):
    p = np.asarray(values, float); ok = np.isfinite(p); out = np.full(len(p), np.nan)
    if not ok.any(): return out
    q = p[ok]; order = np.argsort(q); ranked = q[order]
    adj = np.minimum.accumulate((ranked * len(q) / np.arange(1,len(q)+1))[::-1])[::-1]
    z = np.empty_like(adj); z[order] = np.minimum(adj,1); out[ok] = z
    return out

def stage_group(x):
    s = str(x).upper()
    if "STAGE I" in s and "STAGE II" not in s and "STAGE III" not in s: return "I"
    if "STAGE II" in s and "STAGE III" not in s: return "II"
    if "STAGE III" in s: return "III"
    if "STAGE IV" in s: return "IV"
    return np.nan

def cox_fit(df, covars):
    d = df[["time","event"]+covars].replace([np.inf,-np.inf],np.nan).dropna().copy()
    d = d[(d.time > 0)]
    X = d[covars].astype(float).to_numpy(); t=d.time.to_numpy(float); e=d.event.to_numpy(int)
    order=np.argsort(t); X=X[order]; t=t[order]; e=e[order]
    def llgh(beta):
        eta=X@beta; eta=np.clip(eta,-40,40); ex=np.exp(eta)
        ll=0.; score=np.zeros(len(beta)); hess=np.zeros((len(beta),len(beta)))
        for tt in np.unique(t[e==1]):
            deaths=(t==tt)&(e==1); risk=t>=tt; dd=deaths.sum()
            s0=ex[risk].sum(); s1=(ex[risk,None]*X[risk]).sum(0)
            s2=np.einsum('i,ij,ik->jk',ex[risk],X[risk],X[risk])
            ll += eta[deaths].sum()-dd*np.log(s0)
            score += X[deaths].sum(0)-dd*s1/s0
            hess -= dd*(s2/s0-np.outer(s1/s0,s1/s0))
        return ll,score,hess
    opt=minimize(lambda b:-llgh(b)[0],np.zeros(X.shape[1]),jac=lambda b:-llgh(b)[1],method='BFGS',options={'gtol':1e-8,'maxiter':1000})
    beta=opt.x; ll,score,hess=llgh(beta)
    try: var=np.linalg.inv(-hess)
    except np.linalg.LinAlgError: var=np.linalg.pinv(-hess)
    se=np.sqrt(np.maximum(np.diag(var),0)); z=beta/se; p=2*stats.norm.sf(np.abs(z))
    rows=[]
    for i,c in enumerate(covars):
        rows.append({"term":c,"beta":beta[i],"SE":se[i],"HR":math.exp(beta[i]),"CI95_low":math.exp(beta[i]-1.96*se[i]),"CI95_high":math.exp(beta[i]+1.96*se[i]),"p":p[i]})
    return rows, {"n":len(d),"events":int(e.sum()),"converged":bool(opt.success or np.max(np.abs(score)) < 1e-4),"log_likelihood":ll}

def logrank(time,event,group):
    time=np.asarray(time,float); event=np.asarray(event,int); group=np.asarray(group,int)
    oe=0.; vv=0.
    for tt in np.unique(time[event==1]):
        risk=time>=tt; deaths=(time==tt)&(event==1); n=risk.sum(); n1=(risk&(group==1)).sum(); dd=deaths.sum(); d1=(deaths&(group==1)).sum()
        if n>1:
            oe += d1-dd*n1/n; vv += dd*(n1/n)*(1-n1/n)*(n-dd)/(n-1)
    chi=oe*oe/vv if vv>0 else np.nan
    return stats.chi2.sf(chi,1) if np.isfinite(chi) else np.nan

def km_curve(time,event):
    ix=np.argsort(time); time=np.asarray(time)[ix]; event=np.asarray(event)[ix]
    xs=[0.]; ys=[1.]; s=1.
    for tt in np.unique(time[event==1]):
        n=(time>=tt).sum(); d=((time==tt)&(event==1)).sum(); s*=1-d/n; xs.extend([tt,tt]); ys.extend([ys[-1],s])
    return np.array(xs),np.array(ys)

pat=wide("clinical_patient.json","patientId")
sam=wide("clinical_sample.json","sampleId")
sam["patientId"]=sam.sampleId.str[:12]
clinical=sam.merge(pat,on="patientId",how="left",suffixes=("_sample","_patient"))
clinical=clinical[clinical.SAMPLE_TYPE.eq("Primary")].copy()
clinical=clinical.sort_values("sampleId").drop_duplicates("patientId")
clinical["time"]=pd.to_numeric(clinical.OS_MONTHS,errors="coerce")
clinical["event"]=clinical.OS_STATUS.astype(str).str.startswith("1").astype(int)
clinical["age"]=pd.to_numeric(clinical.AGE,errors="coerce")
clinical["male"]=(clinical.SEX=="Male").astype(float)
clinical["stage_group"]=clinical.AJCC_PATHOLOGIC_TUMOR_STAGE.map(stage_group)
clinical["late_stage"]=clinical.stage_group.isin(["III","IV"]).astype(float)
clinical.loc[clinical.stage_group.isna(),"late_stage"]=np.nan
clinical["ebv_positive"]=(clinical.SUBTYPE=="STAD_EBV").astype(float)
clinical["subtype_known"]=clinical.SUBTYPE.isin(["STAD_EBV","STAD_CIN","STAD_GS","STAD_MSI","STAD_POLE"])

expr=[]
for gene in GENES:
    d=pd.DataFrame(json.loads((RAW/f"expression_{gene}.json").read_text()))[["sampleId","patientId","value"]]
    d[gene]=np.log2(pd.to_numeric(d.value,errors="coerce")+1); expr.append(d[["sampleId","patientId",gene]])
ex=expr[0]
for d in expr[1:]: ex=ex.merge(d,on=["sampleId","patientId"],how="outer")
dat=clinical.merge(ex,on=["sampleId","patientId"],how="inner")
dat=dat[dat.time.notna() & (dat.time>0) & dat.subtype_known].copy()
for gene in GENES:
    dat[gene+"_z"]=(dat[gene]-dat[gene].mean())/dat[gene].std(ddof=0)

rows=[]
for gene in GENES:
    z=gene+"_z"
    fits=[("Univariable_all",dat,[z]),("Multivariable_all",dat,[z,"age","male","late_stage","ebv_positive"]),
          ("Univariable_EBV_positive",dat[dat.ebv_positive==1],[z]),
          ("Univariable_EBV_negative",dat[(dat.ebv_positive==0)&dat.subtype_known],[z]),
          ("Multivariable_EBV_negative",dat[(dat.ebv_positive==0)&dat.subtype_known],[z,"age","male","late_stage"])]
    for model,frame,covs in fits:
        try:
            rr,meta=cox_fit(frame,covs); g=next(x for x in rr if x["term"]==z)
            rows.append({"Gene":gene,"Model":model,**meta,**{k:g[k] for k in ["HR","CI95_low","CI95_high","p"]}})
        except Exception as exc:
            rows.append({"Gene":gene,"Model":model,"n":len(frame),"events":int(frame.event.sum()),"converged":False,"HR":np.nan,"CI95_low":np.nan,"CI95_high":np.nan,"p":np.nan,"error":str(exc)})
    # Interaction model: gene effect modification by EBV, adjusted.
    q=dat.copy(); q["gene_x_ebv"]=q[z]*q.ebv_positive
    try:
        rr,meta=cox_fit(q,[z,"ebv_positive","gene_x_ebv","age","male","late_stage"]); g=next(x for x in rr if x["term"]=="gene_x_ebv")
        rows.append({"Gene":gene,"Model":"Gene_by_EBV_interaction",**meta,**{k:g[k] for k in ["HR","CI95_low","CI95_high","p"]}})
    except Exception as exc: pass

cox=pd.DataFrame(rows)
cox["FDR_BH_within_model"]=cox.groupby("Model")["p"].transform(bh)
cox["Interpretation"]="HR per 1-SD higher log2(RSEM+1) expression"
cox.to_csv(OUT/"Cox_models_all_results.tsv",sep="\t",index=False)

km=[]
for gene in GENES:
    for stratum,frame in [("All STAD",dat),("EBV-positive",dat[dat.ebv_positive==1]),("EBV-negative",dat[(dat.ebv_positive==0)&dat.subtype_known])]:
        f=frame[["time","event",gene]].dropna(); med=f[gene].median(); grp=(f[gene]>=med).astype(int)
        km.append({"Gene":gene,"Stratum":stratum,"n":len(f),"events":int(f.event.sum()),"median_cutpoint_log2_RSEM_plus1":med,"n_high":int(grp.sum()),"n_low":int((1-grp).sum()),"logrank_p":logrank(f.time,f.event,grp)})
km=pd.DataFrame(km); km["logrank_FDR_BH_within_stratum"]=km.groupby("Stratum")["logrank_p"].transform(bh)
km.to_csv(OUT/"Kaplan_Meier_logrank_results.tsv",sep="\t",index=False)

cols=["sampleId","patientId","time","event","age","SEX","stage_group","SUBTYPE","CANCER_TYPE_DETAILED"]+GENES
dat[cols].to_csv(OUT/"Survival_analysis_cohort.tsv",sep="\t",index=False)

sns.set_theme(style="whitegrid")
def forest(model,filename,title):
    d=cox[cox.Model==model].sort_values("HR").copy(); y=np.arange(len(d))
    fig,ax=plt.subplots(figsize=(8,6.5)); sig=d.FDR_BH_within_model<.05
    for yy,(_,r) in enumerate(d.iterrows()):
        color='#D84A3A' if r.FDR_BH_within_model < .05 else '#6B7280'
        ax.errorbar(r.HR,yy,xerr=[[r.HR-r.CI95_low],[r.CI95_high-r.HR]],fmt='o',color=color,ecolor=color,capsize=3,lw=1.6,markersize=6)
    ax.axvline(1,color='black',ls='--',lw=1)
    ax.set_yticks(y,d.Gene); ax.set_xscale('log'); ax.set_xlabel('Hazard ratio per 1-SD higher expression (95% CI)'); ax.set_title(title,fontweight='bold')
    for yy,(_,r) in enumerate(d.iterrows()): ax.text(ax.get_xlim()[1]*1.03,yy,f"FDR {r.FDR_BH_within_model:.3g}",va='center',fontsize=8)
    fig.tight_layout(); fig.savefig(FIG/(filename+'.png'),dpi=600,bbox_inches='tight'); fig.savefig(FIG/(filename+'.pdf'),bbox_inches='tight'); plt.close(fig)
forest("Multivariable_all","Figure_survival_multivariable_forest","Multivariable overall-survival analysis of 12 hub genes")
forest("Univariable_EBV_positive","Figure_survival_EBV_positive_forest","Exploratory Cox analysis within EBV-positive TCGA-STAD")

fig,axes=plt.subplots(3,4,figsize=(15,11),constrained_layout=True)
for ax,gene in zip(axes.flat,GENES):
    f=dat[["time","event",gene]].dropna(); med=f[gene].median(); grp=(f[gene]>=med).astype(int)
    for val,label,color in [(0,"Low","#4C78A8"),(1,"High","#E45756")]:
        x,y=km_curve(f.loc[grp==val,"time"],f.loc[grp==val,"event"]); ax.step(x,y,where='post',label=f'{label} (n={(grp==val).sum()})',color=color)
    p=km[(km.Gene==gene)&(km.Stratum=="All STAD")].iloc[0]
    ax.set_title(f"{gene}  log-rank FDR={p.logrank_FDR_BH_within_stratum:.3g}",fontsize=10,fontweight='bold'); ax.set_ylim(0,1.03); ax.set_xlabel('OS (months)'); ax.set_ylabel('Survival probability'); ax.legend(fontsize=7)
fig.suptitle('Kaplan–Meier overall survival by median hub-gene expression',fontsize=16,fontweight='bold')
fig.savefig(FIG/'Figure_KM_all_12_hub_genes.png',dpi=600,bbox_inches='tight'); fig.savefig(FIG/'Figure_KM_all_12_hub_genes.pdf',bbox_inches='tight'); plt.close(fig)

summary={
 "cohort_n":int(len(dat)),"events":int(dat.event.sum()),"ebv_positive_n":int((dat.ebv_positive==1).sum()),"ebv_positive_events":int(dat.loc[dat.ebv_positive==1,'event'].sum()),
 "primary_model":"Cox OS, expression continuous per 1 SD, adjusted for age, sex, stage (I-II vs III-IV), and EBV status",
 "multiplicity":"Benjamini-Hochberg correction across 12 genes separately within each model family",
 "warning":"EBV-positive stratum has few events; its Cox estimates are exploratory and were not multivariable-adjusted.",
 "significant_multivariable_FDR05":cox.loc[(cox.Model=='Multivariable_all')&(cox.FDR_BH_within_model<.05),'Gene'].tolist(),
 "significant_EBV_positive_univariable_FDR05":cox.loc[(cox.Model=='Univariable_EBV_positive')&(cox.FDR_BH_within_model<.05),'Gene'].tolist(),
 "significant_gene_EBV_interactions_FDR05":cox.loc[(cox.Model=='Gene_by_EBV_interaction')&(cox.FDR_BH_within_model<.05),'Gene'].tolist(),
}
(OUT/'analysis_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
