# TCGA-STAD survival analysis

The package includes the exact local clinical and expression JSON inputs required by `run_survival_analysis.py`, which now resolves paths relative to this package.

The main cohort contained 225 patients and 84 deaths; the covariate-complete multivariable cohort contained 217 patients and 79 deaths. Cox models used continuous z-standardized log2(RSEM + 1) expression and adjusted for age, sex, stage, and EBV status. No hub gene remained independently prognostic after FDR correction.
