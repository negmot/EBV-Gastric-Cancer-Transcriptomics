import json, urllib.request, csv, os, math, textwrap, shutil, zipfile
from pathlib import Path
from collections import Counter, defaultdict

import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
OUT = ROOT
RES = OUT / 'results'
FIG = OUT / 'figures'
PKG = OUT / 'package'
for p in [OUT, RES, FIG, PKG]: p.mkdir(parents=True, exist_ok=True)

GENES = ['CD8A','IFNG','CCR7','PTPR','GZMB','TNFRSF4','NCR1','IL21R','CXCR6','ENTPD1','CD2','LCK']
GENES[3] = 'PTPRC'

query = '''query { genes(names: ["CD8A","IFNG","CCR7","PTPRC","GZMB","TNFRSF4","NCR1","IL21R","CXCR6","ENTPD1","CD2","LCK"]) { nodes { name interactions { drug { name approved antiNeoplastic immunotherapy conceptId } interactionScore evidenceScore geneSpecificity drugSpecificity interactionTypes { type directionality } sources { sourceDbName sourceDbVersion } publications { pmid citation } } } } }'''
req = urllib.request.Request('https://dgidb.org/api/graphql', data=json.dumps({'query': query}).encode(), headers={'Content-Type':'application/json'})
with urllib.request.urlopen(req, timeout=90) as r:
    raw = json.load(r)
(RES/'DGIdb_raw_response.json').write_text(json.dumps(raw, indent=2), encoding='utf-8')

rows=[]
for node in raw['data']['genes']['nodes']:
    gene=node['name']
    for x in node['interactions']:
        types='; '.join(sorted({t['type'] for t in x['interactionTypes'] if t.get('type')}))
        dirs='; '.join(sorted({t['directionality'] for t in x['interactionTypes'] if t.get('directionality')}))
        sources='; '.join(sorted({s['sourceDbName'] for s in x['sources']}))
        versions='; '.join(sorted({f"{s['sourceDbName']} {s['sourceDbVersion']}" for s in x['sources']}))
        pmids='; '.join(str(p['pmid']) for p in x['publications'])
        citations=' | '.join(p.get('citation') or '' for p in x['publications'])
        d=x['drug']
        rows.append(dict(Gene=gene, Drug=d['name'], Concept_ID=d['conceptId'], Approved=bool(d.get('approved')),
                         Antineoplastic=bool(d.get('antiNeoplastic')), Immunotherapy=bool(d.get('immunotherapy')),
                         Interaction_type=types or 'not specified', Directionality=dirs or 'not specified',
                         DGIdb_interaction_score=x['interactionScore'], Evidence_score=x['evidenceScore'],
                         Number_of_sources=len(x['sources']), Sources=sources, Source_versions=versions,
                         PMIDs=pmids, Publications=citations,
                         DGIdb_gene_url=f"https://dgidb.org/genes/{gene}", Retrieved='2026-08-04'))
all_df=pd.DataFrame(rows).sort_values(['Gene','DGIdb_interaction_score','Drug'], ascending=[True,False,True])

# Mechanistically interpretable candidates for the main exploratory display.
excluded_terms = ['[125I]', 'VACCINE', 'ANTIOXIDANT', 'IMMUNOSUPPRESSANT', 'PROTEIN KINASE INHIBITOR',
                  'THERAPEUTIC AUTOLOGOUS', 'THERAPEUTIC GLUCOCORTICOID', 'RECOMBINANT TUMOR NECROSIS',
                  'COBALT', 'HYDROGEN PEROXIDE', 'ZINC CHLORIDE', 'HEPARAN SULFATE', 'BC8 131I']
endogenous_exact = {'CCL19','CCL21','CCL21B','CXCL16'}
def selected(r):
    defined = r.Interaction_type != 'not specified'
    multi = r.Number_of_sources >= 2
    named = not any(t in r.Drug.upper() for t in excluded_terms) and r.Drug.upper() not in endogenous_exact
    return named and (defined or multi)
sel_df=all_df[all_df.apply(selected,axis=1)].copy()
def join_unique(s):
    vals=[]
    for v in s.fillna(''):
        for part in str(v).split('; '):
            if part and part not in vals: vals.append(part)
    return '; '.join(vals)
sel_df=(sel_df.groupby(['Gene','Drug'],as_index=False)
        .agg({'Concept_ID':join_unique,'Approved':'max','Antineoplastic':'max','Immunotherapy':'max',
              'Interaction_type':join_unique,'Directionality':join_unique,'DGIdb_interaction_score':'max',
              'Evidence_score':'max','Number_of_sources':'max','Sources':join_unique,'Source_versions':join_unique,
              'PMIDs':join_unique,'Publications':lambda s:' | '.join(dict.fromkeys(v for v in s if v)),
              'DGIdb_gene_url':'first','Retrieved':'first'}))
sel_df['Evidence_tier']=sel_df.apply(lambda r: 'Tier 1: approved + defined mechanism' if r.Approved and r.Interaction_type!='not specified'
                                    else ('Tier 2: defined mechanism, investigational/other' if r.Interaction_type!='not specified'
                                          else 'Tier 3: multi-source association, mechanism unspecified'), axis=1)
sel_df['Interpretation']='Exploratory drug–gene association; not evidence of efficacy in EBV-positive gastric cancer'
sel_df=sel_df.sort_values(['Evidence_tier','Gene','DGIdb_interaction_score'], ascending=[True,True,False])

summary=[]
for g in GENES:
    a=all_df[all_df.Gene==g]; s=sel_df[sel_df.Gene==g]
    summary.append({'Gene':g,'All_DGIdb_associations':len(a),'Selected_exploratory_associations':len(s),
                    'Approved_selected':int(s.Approved.sum()) if len(s) else 0,
                    'Highest_scoring_selected':s.iloc[0].Drug if len(s) else 'None meeting display criteria',
                    'Interpretation':'Association-generating only'})
summary_df=pd.DataFrame(summary)

all_df.to_csv(RES/'DGIdb_all_interactions_12_hub_genes.tsv',sep='\t',index=False)
sel_df.to_csv(RES/'DGIdb_selected_exploratory_interactions.tsv',sep='\t',index=False)
summary_df.to_csv(RES/'DGIdb_gene_level_summary.tsv',sep='\t',index=False)

# Cytoscape edge/node tables
edges=sel_df[['Gene','Drug','Interaction_type','Directionality','Approved','Antineoplastic','Immunotherapy','DGIdb_interaction_score','Evidence_tier']].copy()
edges.columns=['source','target','interaction','directionality','approved','antineoplastic','immunotherapy','score','evidence_tier']
edges.to_csv(RES/'Cytoscape_drug_gene_edges.tsv',sep='\t',index=False)
nodes=[]
for g in GENES: nodes.append({'id':g,'node_type':'hub gene','approved':False,'label':g})
for _,r in sel_df.drop_duplicates('Drug').iterrows(): nodes.append({'id':r.Drug,'node_type':'drug/agent','approved':bool(r.Approved),'label':r.Drug})
pd.DataFrame(nodes).to_csv(RES/'Cytoscape_drug_gene_nodes.tsv',sep='\t',index=False)

# Network figure: restrict visual clutter to best 4 associations/gene by score, retaining all in tables.
plot_df=pd.concat([g.head(4) for _,g in sel_df.groupby('Gene')], ignore_index=True) if len(sel_df) else sel_df
plt.figure(figsize=(16,12))
ax=plt.gca(); ax.set_xlim(-.1,1.1); ax.set_ylim(-.05,1.05)
genes_present=[g for g in GENES if g in set(plot_df.Gene)]
gene_pos={g:(.12, .95-i*(.9/max(len(genes_present)-1,1))) for i,g in enumerate(genes_present)}
drug_list=list(dict.fromkeys(plot_df.Drug.tolist()))
drug_pos={d:(.88, .97-i*(.94/max(len(drug_list)-1,1))) for i,d in enumerate(drug_list)}
approved_map=plot_df.drop_duplicates('Drug').set_index('Drug').Approved.to_dict()
for _,r in plot_df.iterrows():
    x1,y1=gene_pos[r.Gene]; x2,y2=drug_pos[r.Drug]
    ax.plot([x1,x2],[y1,y2],color='#94A3B8',alpha=.4,linewidth=max(.5,min(3,math.log10(1+r.DGIdb_interaction_score)+.4)),zorder=1)
for g,(x,y) in gene_pos.items():
    ax.scatter([x],[y],s=1100,c='#2FC5F3',edgecolors='#0F172A',linewidths=1.2,zorder=3)
    ax.text(x,y,g,ha='center',va='center',fontsize=8,fontweight='bold',zorder=4)
for d,(x,y) in drug_pos.items():
    ax.scatter([x],[y],s=360,c='#F59E0B' if approved_map[d] else '#CBD5E1',edgecolors='#475569',linewidths=.7,zorder=3)
    ax.text(x-.018,y,'\n'.join(textwrap.wrap(d,28)),ha='right',va='center',fontsize=6.5,fontweight='bold',zorder=4)
plt.title('Exploratory drug–gene associations for the 12 revised hub genes',fontsize=16,fontweight='bold')
plt.text(.5,.01,'Top four selected associations per gene by DGIdb interaction score; orange = DGIdb-approved, gray = investigational/other.\nAssociations do not establish therapeutic efficacy or target validity in EBV-positive gastric cancer.',ha='center',transform=plt.gcf().transFigure,fontsize=9)
plt.axis('off'); plt.tight_layout(rect=[0,.05,1,.96])
plt.savefig(FIG/'Figure_exploratory_drug_gene_network.png',dpi=600,bbox_inches='tight')
plt.savefig(FIG/'Figure_exploratory_drug_gene_network.pdf',bbox_inches='tight')
plt.close()

stats={
 'retrieval_date':'2026-08-04','genes_queried':12,'genes_with_any_association':int((summary_df.All_DGIdb_associations>0).sum()),
 'all_database_records':int(len(all_df)),'all_unique_gene_drug_names':int(all_df[['Gene','Drug']].drop_duplicates().shape[0]),
 'selected_gene_drug_pairs':int(len(sel_df)),
 'selected_unique_agents':int(sel_df.Drug.nunique()),'selected_approved_pairs':int(sel_df.Approved.sum()),
 'genes_without_any_association':summary_df.loc[summary_df.All_DGIdb_associations==0,'Gene'].tolist(),
 'selection_rule':'Named agents with a defined DGIdb interaction type and/or support from at least two aggregated sources; generic classes, radioligands, endogenous ligands, and nonspecific materials were excluded from the main display.',
 'interpretation':'Exploratory hypothesis-generating associations only.'}
(RES/'analysis_summary.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')

md=f'''# Replacement text: exploratory drug–gene association analysis

## Response to Reviewer, Comment 6

**Response:** Thank you for this important comment. We agree that the previous wording overstated the biomarker and therapeutic-target implications of the computational findings. We therefore revised the manuscript to distinguish candidate markers from validated biomarkers and repeated the drug–gene association analysis using the 12 hub genes identified in the reconstructed medium-confidence PPI network (CD8A, IFNG, CCR7, PTPRC, GZMB, TNFRSF4, NCR1, IL21R, CXCR6, ENTPD1, CD2, and LCK). Drug–gene records were retrieved from DGIdb v5.0 and are now reported strictly as exploratory, hypothesis-generating associations. The revised analysis does not interpret database co-annotation as evidence that a gene is a validated therapeutic target or that an associated agent is effective in EBV-positive intestinal-type gastric cancer. Approval status, interaction type, evidence score, aggregated sources, and supporting publications were retained to make the evidence traceable. Generic agents, radioligands, endogenous ligands, and nonspecific materials were excluded from the main network but retained in the complete supplementary table. We have also removed definitive therapeutic-target language and explicitly stated that experimental and disease-specific validation is required.

## Methods

### Exploratory drug–gene association analysis

The 12 revised hub genes were queried against the Drug–Gene Interaction Database (DGIdb v5.0; GraphQL API; accessed August 4, 2026). For each returned gene–agent pair, the DGIdb interaction score, evidence score, interaction type and directionality, regulatory-approval annotation, aggregated source databases, and linked PubMed records were collected. The complete unfiltered output was retained as supplementary data. To improve interpretability of the main visualization, we displayed named agents with a defined DGIdb interaction type and/or evidence aggregated from at least two sources; generic therapeutic classes, radiolabeled probes, endogenous ligands, and nonspecific materials were omitted from the main figure. These database-derived links were treated solely as exploratory drug–gene associations and were not considered evidence of therapeutic efficacy, target dependency, or clinical actionability in EBV-positive gastric cancer.

## Results

### Exploratory drug–gene associations

DGIdb returned {len(all_df)} gene–agent records across {(summary_df.All_DGIdb_associations>0).sum()} of the 12 revised hub genes. After applying the predefined display criteria, {len(sel_df)} gene–agent pairs involving {sel_df.Drug.nunique()} unique agents were retained in the curated exploratory table, including {int(sel_df.Approved.sum())} pairs annotated by DGIdb as involving an approved agent. The distribution of associations was uneven, with kinase-associated LCK accounting for a substantial proportion of records, whereas some immune-marker genes had few or no catalogued interactions. The network therefore reflects differences in database coverage and pharmacologic tractability rather than evidence that the corresponding agents are effective treatments for EBV-positive intestinal-type gastric cancer. All associations should be considered hypothesis-generating and require disease-specific functional validation.

## Discussion/limitations replacement

The drug–gene analysis identifies previously catalogued molecular associations rather than validated therapeutic targets. In particular, an interaction may represent direct binding, pathway modulation, biomarker response, experimental inhibition, or literature co-annotation, and the DGIdb score is an evidence-aggregation metric rather than a measure of anticancer efficacy. The predominance of associations for well-studied proteins such as LCK also introduces knowledge-base and publication bias. Consequently, neither regulatory approval of an associated drug nor the presence of a database link supports its use in EBV-positive gastric cancer. Target dependency, direction of therapeutic modulation, tumor-cell versus immune-cell origin, pharmacologic selectivity, and efficacy would require orthogonal protein-level, perturbational, and disease-relevant experimental validation.

## Figure caption

**Figure X. Exploratory drug–gene association network for the revised hub genes.** The 12 hub genes identified from the reconstructed STRING PPI network were queried in DGIdb v5.0. For readability, the figure displays up to four selected associations per gene ranked by the DGIdb interaction score. Orange agent nodes denote records annotated by DGIdb as approved, whereas gray nodes denote investigational or other agents; blue nodes represent hub genes. Edges indicate database-reported associations and do not establish therapeutic efficacy, target validity, or clinical actionability in EBV-positive intestinal-type gastric cancer. The complete unfiltered output and evidence annotations are provided in Supplementary Table X.

## Supplementary table caption

**Supplementary Table X. Exploratory DGIdb drug–gene associations for the 12 revised hub genes.** The table reports all retrieved gene–agent pairs, including DGIdb interaction and evidence scores, interaction type, directionality, approval annotation, contributing databases, source versions, PubMed identifiers, and retrieval date. These records are hypothesis-generating database associations and should not be interpreted as validated therapeutic targets or treatment recommendations.

## Required terminology changes

- Replace “therapeutic targets” with “genes with exploratory drug–gene associations.”
- Replace “candidate drugs for treatment” with “agents linked to hub genes in aggregated databases.”
- Replace “validated biomarkers” with “candidate EBV-associated markers with external transcriptomic support,” consistent with the separate TCGA analysis.
- Do not infer efficacy, direction of benefit, or EBV-specific action from DGIdb/DrugBank annotations.
'''
(OUT/'Manuscript_and_reviewer_text.md').write_text(md,encoding='utf-8')

readme=f'''DRUG–GENE ASSOCIATION ANALYSIS PACKAGE\n\nScope: 12 revised hub genes\nSource: DGIdb v5.0 GraphQL API, retrieved 2026-08-04\n\nKey result: {len(all_df)} total database records; {len(sel_df)} selected exploratory pairs involving {sel_df.Drug.nunique()} unique agents.\n\nInterpretation: hypothesis-generating associations only. They are not evidence of target validity, efficacy, or treatment recommendations in EBV-positive gastric cancer.\n\nFiles:\n- DGIdb_all_interactions_12_hub_genes.tsv: complete unfiltered output\n- DGIdb_selected_exploratory_interactions.tsv: curated main table\n- DGIdb_gene_level_summary.tsv: counts per gene\n- Cytoscape_drug_gene_edges.tsv / nodes.tsv: editable network input\n- Figure_exploratory_drug_gene_network.png/pdf: publication figure\n- Manuscript_and_reviewer_text.md: ready-to-paste response and manuscript text\n- analysis_summary.json: machine-readable summary\n- build_drug_analysis.py: reproducible retrieval and analysis code\n'''
(OUT/'README.md').write_text(readme,encoding='utf-8')
print(json.dumps(stats,indent=2))
