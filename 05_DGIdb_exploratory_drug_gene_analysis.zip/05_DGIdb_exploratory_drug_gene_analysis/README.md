# DGIdb exploratory drug-gene analysis

DGIdb v5.0 GraphQL API was queried on 2026-08-04 for the 12 revised hub genes. The package contains the raw response, all 167 database records, the selected exploratory display set, gene summaries, Cytoscape import tables, figures, workbook, and a path-portable retrieval/analysis script.

These associations are hypothesis-generating database links and are not evidence of therapeutic efficacy or treatment recommendations in EBV-positive gastric cancer. Re-running the live query at a later date may produce different results as DGIdb changes.
