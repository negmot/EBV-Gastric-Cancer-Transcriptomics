# TCGA-STAD EBV-stratified expression analysis

Primary comparison: all histologies, EBV-positive (n=22) versus EBV-negative (n=225). Sensitivity comparison: explicitly intestinal-type tumors, EBV-positive (n=3) versus EBV-negative (n=34).

The package includes local clinical and per-gene expression JSON inputs, a portable Python script, sample-level outputs, statistics, a formatted workbook, and PNG/PDF figures. Expression was analyzed as log2(RSEM + 1) using two-sided Mann-Whitney U tests, BH correction across 12 genes, and rank-biserial effect sizes.
