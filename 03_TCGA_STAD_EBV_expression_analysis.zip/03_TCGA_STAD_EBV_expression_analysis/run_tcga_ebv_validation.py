#!/usr/bin/env python3
import json, math, os, urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw"
RES = ROOT / "results"
FIG = ROOT / "figures"
for p in (RAW, RES, FIG): p.mkdir(parents=True, exist_ok=True)

STUDY = "stad_tcga_pan_can_atlas_2018"
PROFILE = f"{STUDY}_rna_seq_v2_mrna"
GENES = {
    "CD8A": 925, "IFNG": 3458, "CCR7": 1236, "PTPRC": 5788,
    "GZMB": 3002, "TNFRSF4": 7293, "NCR1": 9437, "IL21R": 50615,
    "CXCR6": 10663, "ENTPD1": 953, "CD2": 914, "LCK": 3932,
}

def bh(pvals):
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    ranked = p[order]
    adj = np.minimum.accumulate((ranked * len(p) / np.arange(1, len(p)+1))[::-1])[::-1]
    out = np.empty_like(adj); out[order] = np.minimum(adj, 1)
    return out

def get_json(url, out):
    if out.exists():
        return json.loads(out.read_text())
    with urllib.request.urlopen(url) as r:
        data = json.load(r)
    out.write_text(json.dumps(data))
    return data

patients = json.loads((RAW / "clinical_patient.json").read_text())
samples = json.loads((RAW / "clinical_sample.json").read_text())

def clinical_wide(rows, key):
    df = pd.DataFrame(rows)
    return df.pivot_table(index=key, columns="clinicalAttributeId", values="value", aggfunc="first").reset_index()

pat = clinical_wide(patients, "patientId")
sam = clinical_wide(samples, "sampleId")
if "patientId" not in sam.columns:
    sam["patientId"] = sam["sampleId"].str.slice(0, 12)
clinical = sam.merge(pat, on="patientId", how="left", suffixes=("_sample", "_patient"))
clinical["is_intestinal"] = clinical["CANCER_TYPE_DETAILED"].eq("Intestinal Type Stomach Adenocarcinoma")
clinical["EBV_group"] = np.where(clinical["SUBTYPE"].eq("STAD_EBV"), "EBV-positive", "EBV-negative")
clinical["subtype_known"] = clinical["SUBTYPE"].isin(["STAD_EBV", "STAD_CIN", "STAD_GS", "STAD_MSI", "STAD_POLE"])

all_expr = []
for gene, entrez in GENES.items():
    url = (f"https://www.cbioportal.org/api/molecular-profiles/{PROFILE}/molecular-data"
           f"?sampleListId={PROFILE}&entrezGeneId={entrez}&projection=DETAILED&pageSize=10000")
    rows = get_json(url, RAW / f"expression_{gene}.json")
    d = pd.DataFrame(rows)[["sampleId", "patientId", "value"]]
    d["Gene"] = gene
    d["Entrez_ID"] = entrez
    d["log2_RSEM_plus1"] = np.log2(pd.to_numeric(d["value"]) + 1)
    all_expr.append(d)
expr = pd.concat(all_expr, ignore_index=True)
dat = expr.merge(clinical[["sampleId", "patientId", "CANCER_TYPE_DETAILED", "SUBTYPE", "is_intestinal", "EBV_group", "subtype_known"]], on=["sampleId", "patientId"], how="left")
analysis = dat[dat["is_intestinal"] & dat["subtype_known"]].copy()
all_stad_analysis = dat[dat["subtype_known"]].copy()

results = []
for gene in GENES:
    g = analysis[analysis.Gene.eq(gene)]
    a = g.loc[g.EBV_group.eq("EBV-positive"), "log2_RSEM_plus1"].dropna().to_numpy()
    b = g.loc[g.EBV_group.eq("EBV-negative"), "log2_RSEM_plus1"].dropna().to_numpy()
    mw = stats.mannwhitneyu(a, b, alternative="two-sided")
    welch = stats.ttest_ind(a, b, equal_var=False)
    # rank-biserial correlation, positive when EBV+ values are higher
    rbc = 2 * mw.statistic / (len(a) * len(b)) - 1
    results.append({
        "Gene": gene, "Entrez_ID": GENES[gene], "n_EBV_positive_intestinal": len(a),
        "n_EBV_negative_intestinal": len(b), "median_EBV_positive": np.median(a),
        "median_EBV_negative": np.median(b), "median_difference_log2": np.median(a)-np.median(b),
        "mean_EBV_positive": np.mean(a), "mean_EBV_negative": np.mean(b),
        "mean_difference_log2": np.mean(a)-np.mean(b), "fold_change_from_mean_log2": 2**(np.mean(a)-np.mean(b)),
        "rank_biserial_correlation": rbc, "Mann_Whitney_U": mw.statistic,
        "Mann_Whitney_p": mw.pvalue, "Welch_t": welch.statistic, "Welch_p": welch.pvalue,
    })
res = pd.DataFrame(results)
res["Mann_Whitney_FDR_BH"] = bh(res["Mann_Whitney_p"])
res["Welch_FDR_BH"] = bh(res["Welch_p"])
res["Direction"] = np.where(res["median_difference_log2"] > 0, "Higher in EBV-positive", "Lower in EBV-positive")
res["FDR_significant"] = res["Mann_Whitney_FDR_BH"] < 0.05
res["Supports_discovery_direction"] = (res["median_difference_log2"] > 0)
res.to_csv(RES / "TCGA_EBV_intestinal_hub_gene_statistics.tsv", sep="\t", index=False)
analysis.to_csv(RES / "TCGA_EBV_intestinal_sample_level_expression.tsv", sep="\t", index=False)

def analyze_frame(frame):
    rows = []
    for gene in GENES:
        g = frame[frame.Gene.eq(gene)]
        a = g.loc[g.EBV_group.eq("EBV-positive"), "log2_RSEM_plus1"].dropna().to_numpy()
        b = g.loc[g.EBV_group.eq("EBV-negative"), "log2_RSEM_plus1"].dropna().to_numpy()
        mw = stats.mannwhitneyu(a, b, alternative="two-sided")
        welch = stats.ttest_ind(a, b, equal_var=False)
        rows.append({"Gene":gene, "Entrez_ID":GENES[gene], "n_EBV_positive":len(a), "n_EBV_negative":len(b),
          "median_EBV_positive":np.median(a), "median_EBV_negative":np.median(b),
          "median_difference_log2":np.median(a)-np.median(b), "mean_EBV_positive":np.mean(a),
          "mean_EBV_negative":np.mean(b), "mean_difference_log2":np.mean(a)-np.mean(b),
          "fold_change_from_mean_log2":2**(np.mean(a)-np.mean(b)),
          "rank_biserial_correlation":2*mw.statistic/(len(a)*len(b))-1,
          "Mann_Whitney_U":mw.statistic, "Mann_Whitney_p":mw.pvalue,
          "Welch_t":welch.statistic, "Welch_p":welch.pvalue})
    out = pd.DataFrame(rows)
    out["Mann_Whitney_FDR_BH"] = bh(out.Mann_Whitney_p)
    out["Welch_FDR_BH"] = bh(out.Welch_p)
    out["Direction"] = np.where(out.median_difference_log2 > 0, "Higher in EBV-positive", "Lower in EBV-positive")
    out["FDR_significant"] = out.Mann_Whitney_FDR_BH < .05
    out["Supports_discovery_direction"] = out.median_difference_log2 > 0
    return out

res_all = analyze_frame(all_stad_analysis)
res_all.to_csv(RES / "TCGA_EBV_all_histologies_hub_gene_statistics.tsv", sep="\t", index=False)
all_stad_analysis.to_csv(RES / "TCGA_EBV_all_histologies_sample_level_expression.tsv", sep="\t", index=False)

counts = (clinical[clinical.subtype_known].groupby(["CANCER_TYPE_DETAILED", "EBV_group"])
          .size().unstack(fill_value=0).reset_index())
counts.to_csv(RES / "TCGA_histology_EBV_group_counts.tsv", sep="\t", index=False)
cohort = clinical[clinical.is_intestinal & clinical.subtype_known][["sampleId","patientId","CANCER_TYPE_DETAILED","SUBTYPE","EBV_group"]].copy()
cohort.to_csv(RES / "TCGA_EBV_intestinal_cohort.tsv", sep="\t", index=False)

sns.set_theme(style="whitegrid", font_scale=1.0)
fig, axes = plt.subplots(4, 3, figsize=(13, 15), constrained_layout=True)
palette = {"EBV-negative":"#4C78A8", "EBV-positive":"#E45756"}
for ax, gene in zip(axes.flat, GENES):
    g = analysis[analysis.Gene.eq(gene)]
    sns.boxplot(data=g, x="EBV_group", y="log2_RSEM_plus1", order=["EBV-negative","EBV-positive"], palette=palette, width=.55, showfliers=False, ax=ax)
    sns.stripplot(data=g, x="EBV_group", y="log2_RSEM_plus1", order=["EBV-negative","EBV-positive"], color="black", alpha=.55, size=3, jitter=.18, ax=ax)
    rr = res[res.Gene.eq(gene)].iloc[0]
    ax.set_title(f"{gene}  (FDR={rr.Mann_Whitney_FDR_BH:.3g})", fontweight="bold")
    ax.set_xlabel(""); ax.set_ylabel("log2(RSEM + 1)")
    ax.set_xticklabels([f"EBV−\n(n={int(rr.n_EBV_negative_intestinal)})", f"EBV+\n(n={int(rr.n_EBV_positive_intestinal)})"])
fig.suptitle("TCGA-STAD validation in intestinal-type gastric adenocarcinoma", fontsize=17, fontweight="bold")
fig.savefig(FIG / "Figure_TCGA_EBV_intestinal_12_hub_genes.png", dpi=600, bbox_inches="tight")
fig.savefig(FIG / "Figure_TCGA_EBV_intestinal_12_hub_genes.pdf", bbox_inches="tight")
plt.close(fig)

fig, axes = plt.subplots(3, 4, figsize=(15, 11), constrained_layout=True)
for ax, gene in zip(axes.flat, GENES):
    g = all_stad_analysis[all_stad_analysis.Gene.eq(gene)]
    sns.boxplot(data=g, x="EBV_group", y="log2_RSEM_plus1", order=["EBV-negative","EBV-positive"], palette=palette, width=.55, showfliers=False, ax=ax)
    sns.stripplot(data=g, x="EBV_group", y="log2_RSEM_plus1", order=["EBV-negative","EBV-positive"], color="black", alpha=.4, size=2.5, jitter=.18, ax=ax)
    rr = res_all[res_all.Gene.eq(gene)].iloc[0]
    ax.set_title(f"{gene}  (FDR={rr.Mann_Whitney_FDR_BH:.3g})", fontweight="bold")
    ax.set_xlabel(""); ax.set_ylabel("log2(RSEM + 1)")
    ax.set_xticklabels([f"EBV−\n(n={int(rr.n_EBV_negative)})", f"EBV+\n(n={int(rr.n_EBV_positive)})"])
fig.suptitle("TCGA-STAD EBV-stratified validation (all gastric adenocarcinoma histologies)", fontsize=16, fontweight="bold")
fig.savefig(FIG / "Figure_TCGA_EBV_all_histologies_12_hub_genes.png", dpi=600, bbox_inches="tight")
fig.savefig(FIG / "Figure_TCGA_EBV_all_histologies_12_hub_genes.pdf", bbox_inches="tight")
plt.close(fig)

plot = res.sort_values("rank_biserial_correlation")
fig, ax = plt.subplots(figsize=(8, 6.5))
colors = np.where(plot.Mann_Whitney_FDR_BH < .05, "#E45756", "#9CA3AF")
ax.barh(plot.Gene, plot.rank_biserial_correlation, color=colors)
ax.axvline(0, color="black", lw=1)
ax.set_xlabel("Rank-biserial correlation (positive = higher in EBV+)")
ax.set_title("Effect sizes for EBV-stratified external validation\nTCGA-STAD intestinal-type tumors", fontweight="bold")
for y, (_, row) in enumerate(plot.iterrows()):
    ax.text(row.rank_biserial_correlation + (.015 if row.rank_biserial_correlation >= 0 else -.015), y,
            f"FDR {row.Mann_Whitney_FDR_BH:.3g}", va="center", ha="left" if row.rank_biserial_correlation >= 0 else "right", fontsize=8)
sns.despine(ax=ax)
fig.tight_layout()
fig.savefig(FIG / "Figure_TCGA_EBV_intestinal_effect_sizes.png", dpi=600, bbox_inches="tight")
fig.savefig(FIG / "Figure_TCGA_EBV_intestinal_effect_sizes.pdf", bbox_inches="tight")
plt.close(fig)

summary = {
    "study": STUDY, "expression_profile": PROFILE,
    "comparison": "EBV-positive vs EBV-negative among intestinal-type stomach adenocarcinoma samples with known TCGA subtype",
    "expression_transform": "log2(batch-normalized RSEM + 1)",
    "primary_test": "two-sided Mann-Whitney U", "multiple_testing": "Benjamini-Hochberg across 12 hub genes",
    "n_ebv_positive_intestinal": int(cohort.EBV_group.eq("EBV-positive").sum()),
    "n_ebv_negative_intestinal": int(cohort.EBV_group.eq("EBV-negative").sum()),
    "genes_fdr_lt_0_05": res.loc[res.Mann_Whitney_FDR_BH < .05, "Gene"].tolist(),
    "genes_directionally_consistent": res.loc[res.median_difference_log2 > 0, "Gene"].tolist(),
    "all_histologies_n_ebv_positive": int(all_stad_analysis.loc[all_stad_analysis.Gene.eq("CD8A"), "EBV_group"].eq("EBV-positive").sum()),
    "all_histologies_n_ebv_negative": int(all_stad_analysis.loc[all_stad_analysis.Gene.eq("CD8A"), "EBV_group"].eq("EBV-negative").sum()),
    "all_histologies_genes_fdr_lt_0_05": res_all.loc[res_all.Mann_Whitney_FDR_BH < .05, "Gene"].tolist(),
    "api_source": "https://www.cbioportal.org/api/",
}
(RES / "analysis_summary.json").write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
