# PPI, hub-gene, and enrichment analysis

`inputs/STRING_input_primary_genes.txt` contains the 606-gene input. STRING associations with combined score >= 0.40 are in `results/STRING_network_primary_score400.tsv`.

The four original cytoHubba exports rank the top five nodes by MCC, MNC, Degree, and DMNC. Their union yields 12 hub genes: CD8A, IFNG, CCR7, PTPRC, GZMB, TNFRSF4, NCR1, IL21R, CXCR6, ENTPD1, CD2, and LCK.

Enrichment tables and raw Enrichr JSON responses are included. A native Cytoscape `.cys` session and separate MCODE/CytoCluster module exports were not present in the retained files and are therefore not included.
